<?php
include "conn.php";

//this code is for profile

if(isset($_POST['pf_submit'])){
          $fn=$_POST["fn"];
          $ln=$_POST["ln"];
          $email=$_POST["email"];
          $phone=$_POST["phone"];
          $date_of_birth=$_POST["date_of_birth"];
          $address=$_POST["address"];
          $city=$_POST["city"];
          $province=$_POST["province"];
          $zip_code=$_POST["zip_code"];
          $country=$_POST["country"];
      
          $insert = mysqli_query($conn,"INSERT INTO user
          VALUES('0','$fn','$ln','$email','$phone','$date_of_birth','$address','$city','$province','$zip_code','$country')");
      
          if($insert == TRUE){
                    ?>
                    <script>
                              alert("Data is Successfully Inserted!");
                              window.location.href="index.php";
                    </script>
                    <?php
          }else{
                    ?>
                    <script>
                              alert("Data os not Inserted!\nPlease try again!");
                              window.location.href="index.php";
                    </script>
                    <?php
          }
      }

//this code is for update

if(isset($_POST['up_submit'])){
          $ref_id = $_GET['id'];

          $a = $_POST['up_fn'];
          $b = $_POST['up_ln'];
          $c = $_POST['up_email'];
          $d = $_POST['up_phone'];
          $e = $_POST['up_date_of_birth'];
          $f = $_POST['up_address'];
          $g = $_POST['up_city'];
          $h = $_POST['up_province'];
          $i = $_POST['up_zip_code'];
          $j = $_POST['up_country'];

          $update_student = mysqli_query($conn, "UPDATE user
          SET fn='$a', ln='$b', email='$c', phone='$d', date_of_birth='$e', address='$f', city='$g', province='$h', zip_code='$i', country='$j' WHERE id='$ref_id'");

          if($update_student == true){
                    ?>
                    <script>
                              alert("Data is Updated!");
                              window.location.href="records.php";
                    </script>
                    <?php
          }else{
                    ?>
                     <script>
                              alert("Error in Upating!");
                              window.location.href="records.php";
                    </script>
                    <?php
          }
}

?>