<!DOCTYPE html>
<html lang="en">
<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Profile Form</title>
          <style>
            *{
              margin: 0;
              padding: 0;
              font-family: sans-serif;
            }
            body{
              position: relative;
              height: 100vh;
            }
            .container{
                position: absolute;
                top: 45%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 50%;
                text-align: center;
                padding: 20px;
                background-color: gray;
                border: 1px solid;
                border-radius: 10px;
            }
            .container .header{
              position: relative;
              padding: 30px;
              color: lightgray;
              border-bottom: 1px solid;
            }
            .container .header .nav{
              position: absolute;
              top: 0;
              left: 40%;
            }
            .container .header .nav a{
              text-decoration: none;
              border: 1px solid;
              color: lightgray;
              padding: 8px;
              border-radius: 5px;
              transition: .4s;
            }
            .container .header .nav a:hover{
              background-color: lightgray;
              color: white;
              border: none;
            }

            .container .form{
              position: relative;
              display: flex;
              flex-wrap: wrap;
              justify-content: space-between;
              margin: 20px 0 12px 0;
            }
            .conatainer .form .box{
              margin-bottom: 15px;
              width: calc(100 / 2 - 20px);
              border-bottom: 1px solid;
            }
            .container .form .box label{
              display: block;
              font-weight: bold;
              margin-top: 20px;
            }
            .container .form .box input{
              height: 45px;
              width: 100%;
              border: none;
              border-radius: 5px;
              padding-left: 15px;
              font-size: 16px;
              border-width: 1px;
              transition: .4s;
              opacity: 0.8;
            }
            .container .form .button{
              position: absolute;
              bottom: 10px;
              right: 30px;
              height: 45px;
              width: 50px 0;
            }
            .container .form .button input{
              height: 100%;
              width: 100%;
              border-radius: 5px;
              border: none;
              font-weight: bold;
              font-size: 18px;
              padding: 10px;
              transition: .4s;
            }
          </style>
</head>
<body>
          <div class="container">
                    <div class="header">
                              <div class="nav">
                                        <a href="index.php">Profile</a> &nbsp;|&nbsp;
                                        <a href="records.php">Records</a>
                              </div> 
                              
                              <div class="title"><h1>Profile Form</h1></div>
                    </div>
                    <form action="process.php" method="POST">
                              <div class="form">
                                        <div class="box">
                                                  <label>First Name: </label> </br>                                       
                                                  <input type="text" name="fn" placeholder="Enter first name" required> </p>
                                        </div>
                                        
                                        <div class="box">
                                                  <label>Last Name: </label> </br>                                       
                                                  <input type="text" name="ln" placeholder="Enter last name" required> </p>
                                        </div>
                                        
                                        <div class="box">
                                                  <label>Email: </label> </br>                                     
                                                  <input type="email" name="email" placeholder="Enter email" required> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Phone Number: </label> </br>                                      
                                                  <input type="number" name="phone" placeholder="Enter phone" required> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Date of Birth: </label></br>                                        
                                                  <input type="date" name="date_of_birth" required> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Address: </label> </br>                                      
                                                  <input type="text" name="address" placeholder="Enter address" required> </p>
                                        </div>

                                        <div class="box">
                                                   <label>City: </label> </br>                                       
                                                   <input type="text" name="city" placeholder="Enter city" required> </p>
                                        </div>

                                        <div class="box">     
                                                  <label>Province: </label> </br>                                       
                                                  <input type="text" name="province" placeholder="Enter province" required> </p>
                                        </div>

                                        <div class="box">  
                                                  <label>Zip Code: </label> </br>                                       
                                                  <input type="number" name="zip_code" placeholder="Enter zip code" required> </p>
                                        </div>
                                        
                                        <div class="box">
                                                  <label>Country: </label> </br>
                                                  <input type="text" name="country" placeholder="Enter country" required> </p>
                                        </div>

                                        <div class="button">
                                                  <input type="submit" name="pf_submit" value="Create Profile">
                                        </div>
                              </div>
                    </form>
          </div>
</body>
</html>