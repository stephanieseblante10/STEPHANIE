<?php
include "conn.php";

$ref_id = $_GET['id'];

$getdata = mysqli_query($conn, "SELECT * FROM profile WHERE id='$ref_id'" );

while($d = mysqli_fetch_object($getdata)){
          $fn = $d -> fn;
          $ln = $d -> ln;
          $email = $d -> email;
          $phone = $d -> phone;
          $date_of_birth = $d -> date_of_birth;
          $address = $d -> address;
          $city = $d -> city;
          $province = $d -> province;
          $zip_code = $d -> zip_code;
          $country = $d -> country;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
          <title>Update Profile</title>
</head>
<body>
          <div class="container">
                    <div class="header">
                              <div class="nav">
                                        <a href="records.php"><i class='bx bx-arrow-back'></i></a>
                              </div> 
                              
                              <div class="title"><h1>Update Records</h1></div>
                    </div>
                    <form action="process.php?id=<?php echo $ref_id; ?>" method="POST">
                              <div class="form">
                                        <div class="box">
                                                  <label>First Name: </label> </br>                              
                                                  <input type="text" name="up_fn" value="<?php echo $fn; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Last Name: </label> </br>                                                                  
                                                  <input type="text" name="up_ln" value="<?php echo $ln; ?>"> </p>
                                        </div> 

                                        <div class="box">
                                                  <label>Email: </label> </br>                                            
                                                  <input type="email" name="up_email" value="<?php echo $email; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Phone Number: </label> </br>                            
                                                  <input type="number" name="up_phone" value="<?php echo $phone; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Date of Birth: </label></br>                                                                      
                                                  <input type="date" name="up_date_of_birth" value="<?php echo $date_of_birth; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Address: </label> </br>                        
                                                  <input type="text" name="up_address" value="<?php echo $address; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>City: </label> </br>                                                                    
                                                  <input type="text" name="up_city" value="<?php echo $city; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Province: </label> </br>                                                                          
                                                  <input type="text" name="up_province" value="<?php echo $province; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Zip Code: </label> </br>                                                                  
                                                  <input type="number" name="up_zip_code" value="<?php echo $zip_code; ?>"> </p>
                                        </div>

                                        <div class="box">
                                                  <label>Country: </label> </br>                                                                   
                                                  <input type="text" name="up_country" value="<?php echo $country; ?>"> </p>
                                        </div>

                                        <div class="button">
                                                  <input type="submit" name="up_submit" value="Update Profile">
                                        </div>
                              </div>
                    </form>
          </div>
</body>
</html>