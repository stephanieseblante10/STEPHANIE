<?php
include "conn.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
          <title>Records Page</title>
          <style>
            .header{
                
            }
            .table_sec{
                border: 1px solid;
            }
          </style>
</head>
<body>    
          <div class="header">    
                    <div class="nav">
                              <a href="index.php">Profile</a> &nbsp;|&nbsp;                              
                              <a href="records.php">Records</a>
                    </div>

                    <div class="title"><h1>Records</h1></div>
          </div>
          <div class="table-sec">          
                    <table>
                              <thead>          
                                        <tr>
                                                  <th>Id</th>                             
                                                  <th>First Name</th>                  
                                                  <th>Last Name</th>                           
                                                  <th>Email</th>                           
                                                  <th>Phone Number</th>                           
                                                  <th>Date of Birth</th>                           
                                                  <th>Address</th>                           
                                                  <th>City</th>                           
                                                  <th>Province</th>                           
                                                  <th>Zip Code</th>                           
                                                  <th>Country</th>                          
                                                  <th>Change</th>                          
                                                  <th>Drop</th>
                                        </tr>
                              </thead>
                              <tbody>
                                        <tr>
                                                  <?php
                                                  $getdata = mysqli_query($conn,"SELECT * FROM user");
                                                  while($row = mysqli_fetch_array($getdata)){
                                                     
                                                  ?>
                                                  
                                                  <td><?php echo $row['id'];?></td>                             
                                                  <td><?php echo $row['first_name'];?></td>                            
                                                  <td><?php echo $row['last_name'];?></td>                            
                                                  <td><?php echo $row['email'];?></td>                           
                                                  <td><?php echo $row['phone'];?></td>                          
                                                  <td><?php echo $row['date'];?></td>                          
                                                  <td><?php echo $row['address'];?></td>                          
                                                  <td><?php echo $row['city'];?></td>                        
                                                  <td><?php echo $row['province'];?></td>                         
                                                  <td><?php echo $row['zip_code'];?></td>                           
                                                  <td><?php echo $row['country'];?></td>                        
                                                  <td class="td-up"><a href="update.php?id=<?php echo $row['id']; ?>">UPDATE</i></a></td>                           
                                                  <td class="td-de"><a href="delete.php?id=<?php echo $row['id']; ?>">DELETE</i></a></td>
                                        </tr>
                                                  <?php
                                                  }
                                                  ?>
                              </tbody>
                    </table>
          </div>       
</body>
</html>