
<?php 
    include "conn.php";
    session_start();

    //for products

    if(isset($_POST['add_products'])){

        $picname = $_FILES['pic']['name'];
        $fileTmpName = $_FILES['pic']['tmp_name'];

        $pn = $_POST['pn'];
        $price = $_POST ['price'];

       $insert = mysqli_query($conn, "INSERT INTO product VALUES('0','$picname','$pn','$price')");

       if($insert == true){

        $fileDestination = 'upload/'.$picname;
        move_uploaded_file($fileTmpName, $fileDestination);

?>

        <script>
        alert("added");
        window.location.href="index.php";
    </script>
    <?php
}else{
     ?>
     <script>
        alert("not");
        window.location.href="addproducts.php";
      </script>
<?php

      
       }

    
    
    }

?>

    <?php
    include "conn.php";
    
    //This code is for registration
    
    if(isset($_POST['reg'])){


        $fn = $_POST['fn'];
        $ln = $_POST['ln'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        
      
    
    //validate
    
    $validate = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    
    
    $val_num=mysqli_num_rows($validate);
    
    if($val_num <= 0){
    
    
    
        //insert data
    
        $insert = mysqli_query($conn, "INSERT INTO users VALUES ('0','$fn','$ln','$email', '$pass')");
    
        if($insert==true){
            ?>
            <script>
                alert("Data is inserted");
                window.location.href="log.php";
            </script>
            <?php
        }else{
             ?>
             <script>
                alert("Data is not inserted");
                window.location.href="index.php";
              </script>
            <?php
        }
        }else{
             ?>
            <script>
                alert ("This email is already in use");
                window.location.href="index.php";
            </script>
            <?php
        }
    
    }
    
    
    if(isset($_POST['login'])){
        $email=$_POST['email'];
    
        $pass=$_POST['pass'];
    
        $check=mysqli_query($conn, "SELECT * FROM users
        WHERE email='$email' AND pass='$pass'");
    
        $num=mysqli_num_rows($check);
    
       if($num >=1 ){
    
            $_SESSION['email']=$email;
            ?>
                     
            <script>
                alert("Account Accepted! Welcome Users!");
                window.location.href="addproducts.php";
                </script>
            <?php
    
       }else{
            ?>
            <script>
                alert("Email or Password not Found!");
                window.location.href="index.php";
                </script>
            <?php
       }
    
    }
    
    
   

    // update


if(isset($_POST['update_bb'])){
    $ref_id = $_GET['id'];
    $a = $_POST['fn'];
    $b = $_POST['ln'];
    $c = $_POST['email'];
    $d = $_POST['pass'];
    
    
    $update_bb = mysqli_query($conn, "UPDATE users
    SET fn='$a',ln='$b',email='$c',pass='$d' WHERE cost_id='$ref_id'");
 if($update_bb == true){
     ?>
 
     <script>
     alert("DATA is UPDATED!");
     window.location.href="record.php";
 </script>
 <?php
 }else{
     ?>
 
     <script>
     alert("Error in Updating!");
     window.location.href="record.php";
 </script>
 <?php
 }
 }
 
    
    ?>
    
    
    