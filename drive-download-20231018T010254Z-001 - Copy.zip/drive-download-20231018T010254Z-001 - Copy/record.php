<?php
include"conn.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
      *{
        background: #00abf0;
        align-items:center;
      }
      body{
        margin: auto;
        font-size:20px;
        color:blue;
      }
     
 

     nav, h1 {
  text-align: center;
  font-size:50px;
    line-height:1.0;
    color:blue;
}



        table {
  border-collapse: collapse;
  width: 100%;
 
}
th, td {
  padding: 3px;
}

td {
  text-align: center;
  font-size:16px;
    line-height:1.1;
    color:black;
}


        </style>
   
<div calss="nav">
        <a href="record.php"> View students</a>&nbsp;|&nbsp;
        <a href="index.php"> LOGOUT </a>
</div>
<h1>List of students </h1>
<table border="5px solid">
<tr>
<th>id</th>
<th>firstname</th>
<th>lastname</th>
<th>Email</th>
<th>Password</th>
<
</tr>

<?php
$getdata = mysqli_query($conn,"SELECT * FROM users");
while($row = mysqli_fetch_array($getdata)){
?>



<tr>
    <td><?php echo $row['cost_id']?></td>
    <td><?php echo $row['fn']?></td>
    <td><?php echo $row['ln']?></td>
    <td><?php echo $row['email']?></td>
    <td><?php echo $row['pass']?></td>
    
    
    
    <td> <a href="update.php?id=<?php echo $row['cost_id'];?>">Update </a> </td>
    <td> <a href="delete.php?id=<?php echo $row['cost_id'];?>">Delete </a> </td>
</tr>

<?php
}
?>



</body>
</html>





