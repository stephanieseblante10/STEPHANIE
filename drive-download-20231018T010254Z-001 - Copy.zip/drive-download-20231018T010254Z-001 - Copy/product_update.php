

<?php
include"conn.php";
$ref_id = $_GET['id'];

$getdata = mysqli_query($conn,"SELECT * FROM product where id='$ref_id'");
while($d=mysqli_fetch_object($getdata)){
    $Email= $d-> email;
    $Password= $d->password;
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPDATE</title>
</head>
<style>
    body{
            background-image: url("img/.jpg");
            background-size: cover;
        }


    
        .nav{

            border: 5px solid black;
            border-radius: 5%;
            text-align: center;
            font-style:highlight;
            color: black;
            background-color: ;
            opacity: .9;
            width: 20%;
            margin-top: 2rem;
            margin-left:25rem;
            width: 40%;

        }
       
        .nav label{
            font-size: 30px;
            margin: 1rem;
            font-weight: bold;
            color:black;
        }
        .nav input{
            font-size:30px;
            margin-left: 4rem;
            margin-bottom: 1rem;
            text-align:center;
            color: block;
            border-radius: 10%;
            border-color: gray;
         

        }
        .nav h1{
            color:red;
        }



       

    
</style>
<body>


<div class="nav">
<h1>Update Records </h1>
<form action="process.php?id=<?php echo $ref_id;?>" method="POST">



    <label>picture</label> </br>
    <input type="text" name="picname"value="<?php echo $Picture;?>"required> </p>

    <label>Producct Name</label> </br>
    <input type="text" name="pn"value="<?php echo $Producct_Name;?>"required> </p>

    <label>Price</label> </br>
    <input type="text" name="price"value="<?php echo $Price;?>"required> </p>

<input type="SUBMIT" name="update_bb"value="UPDATE">

</form>
    
</body>
</html>

