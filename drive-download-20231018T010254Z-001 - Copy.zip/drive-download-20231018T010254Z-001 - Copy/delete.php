<?php
include"conn.php";
$ref_id = $_GET['id'];

$delete = mysqli_query($conn,"DELETE FROM users  where cost_id='$ref_id'");

if($delete == true){
    ?>

    <script>
    alert("1 data is deleted!");
    window.location.href="record.php";
</script>
<?php
}else{
    ?>
        <script>
        alert("error in deleting!");
        window.location.href="record.php";
    </script>
    <?php
}
?>
