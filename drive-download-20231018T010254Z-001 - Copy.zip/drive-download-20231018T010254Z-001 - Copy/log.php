





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inventory system</title>
</head>
<title></title>
<link rel="stylesheet"href="style.css">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<style>
*{
  margin: 0;
  padding: 0;
}
.main{
  width: 100;
  opacity: 1;
  background: linear-gradient(to top,rgba(0,0,0,0.5)50%,rgba(0,0,0,0.5)50%),url(img/1.jpg);
  background-position: center;
  background-size: cover;
  height: 100vh;

  

}
.navbar{
  width: 1100px;
  height: 75px;
  margin: auto;

}

ul{
  float: left;
  display: flex;
  justify-content: center;
  align-items: center;
}
ul li{
  list-style: none;
  margin-left: 62px;
  margin-top: 27px;
  font-size: 14px;
}
ul li a{
  text-decoration: none;
  color: #fff;
  font-family: Arial;
  font-weight: bold;
  transition: 0,4s ease-in-out;
}
ul li a:hover{
  color:#f17200;
}
.search{
  width: 330px;
  float: left;
  margin-left: 270px;
}
.srch{
  font-family:'Times New Roman';
  width:200px;
  height: 40px;
  background: transparent;
  border: 1px solid #ff7200;
  margin-top: 13px;
  color: #fff;
  border-right: none;
  font-size: 15px;
  float: left;
  padding: 10px;
  border-bottom-left-radius: 5px;
  border-top-left-radius: 5px;
}
.btn{
  width: 100px;
  height: 40px;
  background: #ff7200;
  border: 2px solid #ff7200;
  margin-top: 13px;
  color: #fff;
  font-size: 15px;
  border-bottom-right-radius: 5px;
  border-bottom-right-radius: 5px;
}
.btn:focus{
  outline: none;
}
.srch:focus{
  outline: none;
}

.content{
  width: 1200px;
  height: auto;
  color: #fff;
  position: relative;
}
.content .par{
  padding-left: 20px;
  padding-bottom: 25px;
  font-family: Arial;
  letter-spacing: 1.2px;
  line-height: 30px;

}
.content h1{
  font-family: 'Times New Roman';
  font-size: 50px;
  padding-left: 20px;
  margin-top: 9%;
  letter-spacing: 2px;

}
.content .cn{
  width: 160px;
  height: 40px;
  background: #ff7200;
  border: none;
  margin-bottom: 18px;
  margin-left: 20px;
  font-size: 18px;
  border-radius: 10px;
  cursor: pointer;
  transition: 4s ease;
}
.content .cn a{
  text-decoration: none;
  color:#000;
  transition: .3s ease;
}

.cn:hover{
  background-color: #fff;
}

.content span{
  color: #ff7200;
  font-size: 60px;
}

.form{
  width: 250px;
  height: 380;
  background: linear-gradient(to top,rgba(0,0,0,0.5)50%,rgba(0,0,0,0.5)50%);
  position: absolute;
  top: 20px;
  left: 870px;
  border-radius: 10px;
  padding: 25px;
}

.form h1{
  width: 220px;
  font-family: sans-serif;
text-align: center;
color: #ff7200;
font-size: 22px;
background-color: #fff;
border-radius: 10px;
margin: 1px;
padding: 8px;

}
.form input{
  width: 230px;
  height: 30px;
  background: transparent;
  border-bottom: 1px solid #fff;
  border-top: none;
  border-right: none;
  border-left: none; 
   
    border-radius: 10px;


    color: #ff2700;
  font-size: 18px;
  letter-spacing: 1px;
  margin-top: 30px;
  font-family: sans-serif;
  
}
.form input:focus{
  outline: none;

}

::placeholder{
  color: #fff;
  font-family: Arial;
}
.btnn{
  width: 240px;
  height: 40px;
  background: #ff7200;
  border: none;
  margin-top: 30px;
  font-size: 18px;
  border-radius: 10px;
  cursor: pointer;
  color: #fff;
}
.btn:hover{
  background: #fff;
  color: #ff7200;

}

.btn a{
  text-decoration: none;
  color: #000;
}
.form .link{
  font-family: Arial, Helvetica, sans-serif;
  font-size: 17px;
  padding: 20px;
  text-align: center;
}

.form .link a{
  text-decoration: none;
  color: #ff7200;
}
.liw{
padding-top: 15px;
padding-bottom: 10px;
text-align: center;
}


.icons a{
  text-decoration: none;
  color: #fff;

}
.icons ion-icon{
  color: #fff;
  font-size: 30px;
  padding-left: 14px;
  padding-top: 5px;
  transition: 0.3s ease;
}

.icons ion-icon:hover{
  color: #ff7200;
}
</style>

<body>
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo"><i class="#" aria-hidden="true"></i></h2>

            </div>
          


   
        <div class="content">
            <h1>INVENTORY & <br><span>SYSTEM</span><br></h1>
            <p class="par">fgfhnjmk,l.;/';.l,kjhvfcdfgthikolphyfds</p>

        <button class="cn"><a href="#">Join us</a></button>




        <div class="form">
    <h1> Login here..! </h1>


<form action="process.php" method="POST">

<labe> Email </label></br>
<input type="email" name="email" required> </p>


<labe> password </label></br>
<input type="password" name="pass" required> </p>



<input type="Submit" name="login" value="LOGIN"> 

</form>
                

               
                <p class="liw">log in with</p>

            <div class="icons">
                <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
                <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                <a href="#"><ion-icon name="logo-skype"></ion-icon></a>

            </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>

</body>
</html>